const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Replace with your actual MongoDB URI
const mongoURI = 'mongodb://localhost:27017/votingapp';

mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Vote schema
const voteSchema = new mongoose.Schema({
  voterName: { type: String, required: true },
  age: { type: Number, required: true },
  voterId: { type: String, required: true, unique: true }, // unique to avoid duplicate voting
  party: { type: String, required: true }
});

const Vote = mongoose.model('Vote', voteSchema);

// Submit vote
app.post('/submit-vote', async (req, res) => {
  try {
    const { voterName, age, voterId, party } = req.body;

    if (!voterName || !age || !voterId || !party) {
      return res.status(400).json({ error: 'All fields are required.' });
    }

    if (age < 18) {
      return res.status(400).json({ error: 'Must be 18 or older to vote.' });
    }

    // Check duplicate voterId
    const existingVote = await Vote.findOne({ voterId });
    if (existingVote) {
      return res.status(400).json({ error: 'You have already voted.' });
    }

    const vote = new Vote({ voterName, age, voterId, party });
    await vote.save();

    res.json({ message: 'Vote submitted successfully!' });
  } catch (err) {
    console.error(err);
    // Handle duplicate key error from MongoDB unique constraint
    if (err.code === 11000) {
      return res.status(400).json({ error: 'You have already voted.' });
    }
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all votes
app.get('/votes', async (req, res) => {
  try {
    const votes = await Vote.find().sort({ _id: -1 });
    res.json(votes);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch votes' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
